README.MD

Mical Nobel
A5

tested in chrome.

things I think I did correctly
- Made consistent and constant commits 
- Used significant commit messages
- Had a .gitignore file in repo
- Created a POST API that would
	- allow any HTML5 game on any web domain send high scores
	- require fields: game_title, username, score
- Created a GET API that returned the top 10 scores in descending order and as a jason string
- had an index as described in the handout
- usersearch behaved as described in handout

I worked alone on this project. It took me ~12 hours.